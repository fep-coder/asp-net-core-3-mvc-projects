﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using StandaloneLessons.Models;

namespace StandaloneLessons.Controllers
{
    public class ProductsController : Controller
    {
        private readonly IRepository repository;

        public ProductsController(IRepository repository)
        {
            this.repository = repository;
        }

        public IActionResult Index()
        {
            //return View(new Repository().Products);
            return View(repository.Products);
        }
        
        public IActionResult Create()
        {
            repository.AddProduct(new Product { Name = "Apples", Price = 1.50M });

            return RedirectToAction("Index");
        }


    }
}